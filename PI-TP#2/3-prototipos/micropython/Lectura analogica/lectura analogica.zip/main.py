import machine
import time
import math

# Configuración del pin del sensor de temperatura
temp_pin = machine.Pin(01)

# Lectura del valor del sensor de temperatura
temp_data = machine.ADC(temp_pin).read_u16()

# Conversión del valor a temperatura en grados Celsius

BETA = 3950 # should match the Beta Coefficient of the thermistor

temp_celsius = 1 / (math.log(1 / (65535 / temp_data - 1)) / BETA + 1.0 / 298.15) - 273.15;

# Impresión del valor de temperatura en el Serial Monitor
print("Temperatura: {:.1f}°C".format(temp_celsius))

# Repetir la lectura cada segundo
while True:
    time.sleep(1)
    temp_data = machine.ADC(temp_pin).read_u16()
    temp_celsius = 1 / (math.log(1 / (65535 / temp_data - 1)) / BETA + 1.0 / 298.15) - 273.15;
    print("Temperatura: {:.1f}°C".format(temp_celsius))