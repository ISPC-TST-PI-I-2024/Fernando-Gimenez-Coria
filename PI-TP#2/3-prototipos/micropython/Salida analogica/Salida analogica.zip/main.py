import time
import math
from machine import PWM
from machine import Pin
from machine import ADC


pot_pin = ADC(Pin(01)) # Configuración del pin del potenciometro

while True:
    
    pot_data = int (pot_pin.read()/4) # Lectura del valor del cursor del potenciometro y acondicionamiento

    pwm0 = PWM(Pin(5), freq = 5000, duty = pot_data) # Asignacion de valor PWM de acuerdo a potenciometro
    
    print("Valor pote: {:.1f}".format(pot_data)) # Impresión del valor tomado del potenciometro

    print("Ciclo de trabajo: {:.1f}%".format((pot_data/1024)*100)) # Impresión del valor de ciclo de trabajo

    time.sleep(0.1) #Espero 100 milisegundos
   
