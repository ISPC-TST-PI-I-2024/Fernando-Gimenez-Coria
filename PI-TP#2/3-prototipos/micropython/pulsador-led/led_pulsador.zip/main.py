from machine import Pin
from utime import sleep



led = Pin(5, Pin.OUT)
pulsador = Pin(6, Pin.IN, Pin.PULL_UP)
while True:

    if (pulsador.value() == False):
        led.on()
        print("boton pulsado")
    else:  
        led.off()
    

